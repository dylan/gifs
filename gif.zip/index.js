import {h, app} from 'hyperapp'

const accessKeyID = 'AKIAJSCHVMKXUBSNYH2A'
const secretAccessKey = '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'

const s3 = new AWS.S3({
    credentials: new AWS.Credentials({
        accessKeyId: accessKeyID,
        secretAccessKey: secretAccessKey
    })
})

const params = {
    Bucket: 'gif.dyli.sh'
}

const filteredItems = ["index.html", "robots.txt", "bundle.js"]

const ListItem = ({item}) => (
    <li>
        <a href={`http://${params.Bucket}/${item.name}`}>{ item.name }</a>
        <span>{ item.lastModified.toString() }</span>
    </li>
)

const Sort = {
    Asc: 0,
    Desc: 1
}

function sortItem(mode, a, b) {
    const [aTime, bTime] = [a.lastModified.getTime(), b.lastModified.getTime()]
    if (aTime < bTime) {
        return mode == Sort.Asc ? -1 : 1
    }
    if (aTime > bTime) {
        return mode == Sort.Asc ? 1 : -1
    }
    return 0
}

app({
    state: {
        "items": [],
        "filter": null,
        "sort": Sort.Asc
    },

    view: (state, actions) => {
        const items = state.items
                        .sort((a, b) => sortItem(state.sort, a, b))
                        .filter(item => !filteredItems.includes(item.name.toLowerCase()))
                        .filter(item => {
                            if(!state.filter) return true
                            return item.name.match(state.filter)
                        })

        return (
            <main>
                <input placeholder='Search...' type='text' oninput={ actions.search }/>
                <a onclick={ actions.toggleSort }>Sort</a>
                <ul>
                    { items.map( item => <ListItem item={item} />) }
                </ul>
            </main>
        )
    },

    actions: {
        toggleSort: (state, actions) => {
            return { sort: state.sort == Sort.Asc ? Sort.Desc : Sort.Asc }
        },

        search: (state, actions, event) => {
            return { filter: event.target.value.trim().toLowerCase() }
        },

        loadBucket: (state, actions) => {
            s3.listObjectsV2(params, (err, data) => {
                if (err) throw err
                actions.updateItems(data)
            })
        },

        updateItems: (state, actions, data) => {
            return { items: data.Contents.map(obj => ({ name: obj.Key, lastModified: obj.LastModified })) }
        }
    },

    events: {
        init: (state, actions) => {
            actions.loadBucket()
        }
    }
})

